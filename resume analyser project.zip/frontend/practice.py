# List=[]
# print("Intial blank List:")
# print(List)
# #Addition of element in the list
# List.append(1)
# List.append(2)
# List.append(3)
# List.append(4)
# print("list of addition of element:")
# print(List)


# List=[1,2,3,4,5,6,7,8,9,]
# print("Intial blank List:")
# print(List)
# List.insert(1,9)
# print(List)
# List.insert(2,'VIT')
# print(List)
# List.remove(6)
# for i in range(1,5):
#     List.remove(i)
#     print(List)

# List=[1,2,3,4,5]
# print(List)
# List.pop()
# print(List)
# List.pop(2)
# print(List)


# dictionary
# dict = {
#     "table" : ["a piece of furniture","list of facts & figures"],
#     "cat" : "a small animal"
# }
# print(dict)

# n=int(input("Enetr a number"))
# sum=0
# i=1
# while i<=n:
#     sum += i
#     i += 1

#     print(sum)

#factorial 
# n=int(input("Enter a number"))
# fact=1
# i=1
# while i<= n:
#     fact*=i
#     i+=1
#     print(fact)




#lab program




# nums=[1,3,4,5,6,7]
# def cal_len(List):
#     print(len(List))
# cal_len(nums)


n=5
def cal_fact(n):
    fact=1
    for i in range(1,n+1):
        fact+=1
        print(fact)
        cal_fact(5)
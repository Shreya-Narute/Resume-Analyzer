<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resume Analyzer</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>🚀 Resume Analyzer</h1>
        <p>Upload your resume and discover your strengths, weaknesses, and best career matches!</p>
        
        <form id="uploadForm" enctype="multipart/form-data">
            <div class="upload-box">
                <input type="file" id="resumeInput" accept=".pdf, .doc, .docx" required>
                <label for="resumeInput">Choose your resume</label>
            </div>
            <button type="submit" class="analyze-btn">Analyze Resume</button>
        </form>

        <div id="result" class="result-box hidden">
            <h2>📋 Analysis Result</h2>
            <div id="strengths" class="result-section"></div>
            <div id="weaknesses" class="result-section"></div>
            <div id="recommendations" class="result-section"></div>
        </div>
    </div>

    <script src="script.js"></script>
</body>
</html>

# AI-Resume-Analyzer-Python-Course-Project
Link: <a>https://resume-analyzer-app-python-project.streamlit.app/</a>
